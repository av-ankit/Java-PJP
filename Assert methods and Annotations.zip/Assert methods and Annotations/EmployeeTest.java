import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;
public class EmployeeTest {
	Employee e = new Employee();
	ArrayList<String> list = new ArrayList<>();
	{
		list.add("Nike");
		list.add("Ankit");
		list.add("Sam");
	}

	@Test
	public void testFindName() {
		System.out.println(list);
		assertEquals("Result", "FOUND", e.findName(list, "Ankit"));
		assertEquals("Result", "NOT FOUND", e.findName(list, "Tushar"));

		System.out.println("test");
	}



}
