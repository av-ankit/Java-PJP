package string_stringbuffer;

public class S03 {

	public static void main(String[] args) {
		String s1="wipro";
		int n=s1.length(),i;
		s1=s1.substring(0, 2);
		for(i=0;i<n;i++)
		{
			System.out.print(s1);
		}
	}

}
