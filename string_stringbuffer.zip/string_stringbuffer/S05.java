package string_stringbuffer;
import java.util.*;
public class S05 {

	public static void main(String[] args) {
	Scanner s= new Scanner(System.in);
	String s1;
	System.out.println("Enter a string:");
	s1=s.nextLine();
	
	int n=s1.length();
	s1=s1.substring(1,n-1);
	System.out.println(s1);
	}

}
