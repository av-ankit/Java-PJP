package string_stringbuffer;
import java.util.*;
public class S08 {

	public static void main(String[] args) {
		
Scanner s=new Scanner(System.in);
System.out.println("Enter a string with '*' in it:");
	String s1=s.nextLine();
	int n=s1.indexOf('*');
	String s2=s1.substring(0, n-1);
	String s3=s1.substring(n+2);
	System.out.println(s2+s3);
	}

}

