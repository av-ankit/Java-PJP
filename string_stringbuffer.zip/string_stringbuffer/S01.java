package string_stringbuffer;
import java.lang.StringBuffer;

public class S01 {

	public static void main(String args[])
	{
		StringBuffer s=new StringBuffer("ANKNA") ;
		StringBuffer r= s.reverse();
		
		if(s.equals(r))
		{
			System.out.println("String is Palindrome :)");
		}
		else
			System.out.println("String is not Palindrome:(");
	}
	 
}
