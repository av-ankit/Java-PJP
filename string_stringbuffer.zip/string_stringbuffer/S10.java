package string_stringbuffer;

public class S10 {

	public static void main(String[] args) {
	String s1="wipro";
	int n=3;
	for(int i=0;i<n;i++)
	{
		System.out.print(s1.substring(s1.length()-n));
	}
	}

}

