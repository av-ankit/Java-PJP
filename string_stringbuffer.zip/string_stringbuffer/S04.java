package string_stringbuffer;

public class S04 {

	public static void main(String[] args) {
		String s1="ANKITV";
		int n=s1.length();
		if(n%2==0)
		{
			System.out.println(s1.substring(0,n/2));
		}
		else
			System.out.println("null");
	}

}
