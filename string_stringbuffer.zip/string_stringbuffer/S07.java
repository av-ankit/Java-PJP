package string_stringbuffer;

public class S07 {

	public static void main(String[] args) {
		String s1="xhix";
		String s2=s1;
		if(s1.startsWith("x")&&s1.endsWith("x"))
		{
			s2=s2.substring(1, s1.length()-1);
			System.out.println(s2);
		}
		else
			System.out.println(s1);
	}

}
