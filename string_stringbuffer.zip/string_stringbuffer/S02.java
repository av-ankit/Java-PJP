package string_stringbuffer;
import java.lang.*;
public class S02 {

	public static void main(String[] args) {
	
		String s1="MARK";
		String s2="KATE";
		
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		
		StringBuffer s3=new StringBuffer(s1);
		if(s3.charAt(s3.length()-1)==s2.charAt(0))
				{
					s3.append(s2.substring(1));
				}
		else
			s3.append(s2);
		
		System.out.println(s3);
		
	}

}
