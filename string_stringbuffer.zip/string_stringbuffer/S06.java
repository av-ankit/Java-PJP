package string_stringbuffer;

public class S06 {

	public static void main(String[] args) {
		String s1="hi",s2="hello";
		if(s1.length()<s2.length())
		{
			System.out.println(s1+s2+s1);
		}
		else
			System.out.println(s2+s1+s2);

	}

}
