package overriding_polymorphism;

public class Pro1 {
	public static void main(String[] args) {
		new Fruit().eat();
		new Apple().eat();
		new Orange().eat();

	}
}
