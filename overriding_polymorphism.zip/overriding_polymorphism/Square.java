package overriding_polymorphism;

public class Square extends Shape {
	public void draw() {
		System.out.println("Drawing Square");
	}
	
	
	public void erase() {
		System.out.println("Erasing Square");
	}
}
