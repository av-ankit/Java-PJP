package overriding_polymorphism;

public class Apple extends Fruit {

	public void eat() {
		System.out.println("Taste - Apple");
	}
}
