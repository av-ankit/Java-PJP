package com.wipro.automobile.ship;

public class Pro2 {

	public static void main(String[] args) {
		Compartment compartment = new Compartment(8745.15, 523.5, 84.2);
		
		System.out.println(compartment);
	}

}