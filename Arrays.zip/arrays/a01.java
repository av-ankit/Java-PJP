package arrays;

public class a01 {

	public static void main(String[] args) {
		
		int ar[]= {1,22,13,84,5},s=0;
		int len=ar.length;
		for(int i=0;i<len;i++)
		{	s+=ar[i];
			
		}
		System.out.println("Sum of array:"+s);
		int av=s/len;
		System.out.println("Average of array:"+av);
		
	}

}
