package arrays;

public class a02 {

	public static void main(String[] args) {
int ar[]= {11,2,3,454,5,6,887};
int len=ar.length,min=2344456,max=0;
for(int i=0;i<len;i++)
{
	if(max<ar[i])
	{
		max=ar[i];			
	}
	else if(min>ar[i])
	{
		min=ar[i];
	}
}

System.out.println(" Minimum value = "+min);
System.out.println(" Maximum value = "+max);
	}

}
