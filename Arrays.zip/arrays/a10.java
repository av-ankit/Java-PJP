package arrays;

public class a10 {
public static void main(String args[])
{
	
	int a=args.length;
    int i,m=Integer.MIN_VALUE;
    int arr[][] = new int[4][4];
    if(a<9)
    {
    System.out.println("enter 4 values");
    }
    if(a==9)
        
    {
        int k=0;
    for(i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            
        arr[i][j]=Integer.parseInt(args[k]);
        k++;
        }
        
    }
    System.out.println("The given array is:");
    for(i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
        System.out.print(arr[i][j]+" ");
        }
        System.out.println();
        
    }
    System.out.println("The biggest number is:");
    for(i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
        if( a[i][j]>m)
        {
        	m=a[i][j];
        }
        }
        
        
    }
System.out.print(m);
    
    }
    
}
}
