package arrays;

public class a06 {

	public static void main(String[] args) {
		int a[]= {6,5,4,1,2,0};
		int i,j,t;
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
	for(i=0;i<a.length;i++)	
		System.out.print(a[i]+" ");

	}

}
