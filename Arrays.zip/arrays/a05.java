package arrays;

public class a07 {

	public static void main(String[] args) {
		int a[]= {1,2,3,44,6,55};
		int max1=a[0],max=a[1],min;
		int min1=min=Integer.MAX_VALUE,t;
		
		if(max1>max)
		{
			t=max1;
			max1=max;
			max=t;
		}
		
		
		for(int i=2;i<a.length;i++)
		{
			
			if(max1<a[i])
			{
				max=max1;
				max1=a[i];
			}
			if(min1>a[i])
			{
				min=min1;
				min1=a[i];
			}
		}
		
		for(int i=0;i<a.length;i++)
		{
			
			if(min1>a[i])
			{
				min=min1;
				min1=a[i];
			}
		}
		
		System.out.println(" max1= "+max1);
		System.out.println("max 2=  "+max);
		System.out.println(" min 1= "+min1);
		System.out.println(" min 2= "+min);
	}

}
