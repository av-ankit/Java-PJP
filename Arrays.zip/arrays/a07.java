package arrays;

public class av07 {

	public static void main(String[] args) {
		int a[]= {10,12,14,23,45,12,23,14,46};
		int lens=a.length;
		
		int i,j,k;
		for(i=0;i<lens;i++)
		{
			for(j=i+1;j<lens;)
			{
				if(a[j]==a[i])
				{
					for(k=j;k<lens;k++)
					{
						a[k]=a[k+1];
					}
					lens--;
				}
				else {
					j++;
				}
			}
			}
		for(i=0;i<lens;i++)
		{
			System.out.print(a[i]+" ");
		}
		}
		
	}


