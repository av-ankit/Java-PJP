package arrays;
import java.util.Scanner;
public class a03 {

	public static void main(String[] args) {
		int a[]= {1,2,3,55,32,67};
		int len=a.length;
		Scanner s=new Scanner(System.in);
		System.out.println("enter a number to search:");
		int x=s.nextInt();
		int f=0,i;
		for(i=0;i<len;i++)
		{
			if(x==a[i])
			{
				
				f=1;
				break;
			}
		}
		if(f==0)
		{
			System.out.println("element not found");
			
		}
		else
		{
			System.out.println(i+1);
		}
		
	}

}
