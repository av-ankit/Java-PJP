package inheritance;

public class Student extends Person3 {
	private int roll;
	public Student(String name, int roll) {
		super(name);
		this.roll = roll;
	}
	
	public String toString() {
		return "Student [rollno=" + roll + "]";
	}
}