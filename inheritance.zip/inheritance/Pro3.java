package inheritance;

public class Pro3 {

	public static void main(String[] args) {
		CollegeStudent stud = new CollegeStudent("Ankit",15,4," CSE");
		System.out.println(stud);

		Teacher teach = new Teacher("Ankit ",1500000,"Science");
		System.out.println(teach);
	}

}