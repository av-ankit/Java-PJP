package inheritance;

public class TestEmployee {

	public static void main(String[] args) {
		Employee employee = new Employee("ANKIT", 10252450, 2020, "3xINDaa78oo098");
		System.out.println(employee);
	}

}