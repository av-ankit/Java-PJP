package inheritance;

public class Person3 {
	private String name;
	public Person3(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}
}
