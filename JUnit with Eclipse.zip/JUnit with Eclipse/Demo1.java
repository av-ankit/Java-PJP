package junit.first;

public class Demo1 {

	public String stringConcat(String a,String b)
	{
		String c=a+b;
		return c;
	}
	
}
