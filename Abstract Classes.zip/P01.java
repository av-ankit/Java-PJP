package abstraction_packages_exceptionhandling;

public class P01 {
public static void main(String args[]) {
	ICICIBank i=new ICICIBank();
	KotMBank k=new KotMBank();
	
    System.out.println("ICICIBank Savings Interest Rate is= " + i.getSavingsInterestRate());
	
	System.out.println("ICICIBank FixedDeposit Interest Rate is= " + i.getFixedDepositInterestRate());
	System.out.println("KotMBank Savings Interest Rate is= " + k.getSavingsInterestRate());
	System.out.println("KotMBank FixedDeposit Interest Rate is= " + k.getFixedDepositInterestRate());
	
	GeneralBank g=new KotMBank();
	System.out.println("General (KotMBank Savings) Interest Rate is= " + g.getSavingsInterestRate());
	System.out.println("General (KotMBank) FixedDeposit Interest Rate is= " + g.getFixedDepositInterestRate());
	
	
	GeneralBank g2=new ICICIBank();
System.out.println("General (ICICIBank) Savings Interest Rate is= " + g2.getSavingsInterestRate());
	
	System.out.println("General (ICICIBank) FixedDeposit Interest Rate is= " + g2.getFixedDepositInterestRate());
	
	
}
}
