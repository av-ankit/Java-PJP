package abstraction_packages_exceptionhandling;

public abstract class Compartment {
	public abstract void notice();
}