package abstraction_packages_exceptionhandling;

public class Luggage extends Compartment {

	
	public void notice() {
		System.out.println("Notice: You're in Luggage");
	}

}
