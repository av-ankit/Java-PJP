package abstraction_packages_exceptionhandling;

public class ICICIBank extends GeneralBank{

	public double getSavingsInterestRate()
	{
		return 4;
	}
	
	public double getFixedDepositInterestRate() {
		return 9.4;
	}
}
