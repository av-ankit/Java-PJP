package abstraction_packages_exceptionhandling;

public class KotMBank extends GeneralBank {

	public double getSavingsInterestRate()
	{
		return 6;
	}
	
	public double getFixedDepositInterestRate() {
		return 9;
	}
	
}
