package classes_objects;



public class Box {
	 private double width;
	    private double height;
	    private double depth;
	    
	    public Box(final double width, final double height, final double depth) {
	        this.width = width;
	        this.height = height;
	        this.depth = depth;
	    }
	    
	    public double clacvol() {
	        return width * height * depth;
	    }
	
}

class pro1{

public static void main(String args[])
{
Box b=new Box(2,4,6);
System.out.println(b.clacvol());
}
}
