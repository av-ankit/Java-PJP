package List;
import java.util.*;
public class P03 {
	
	public static void printAll(List<String> li) {
		Iterator<String> it = li.iterator();
		
		while (it.hasNext())
			System.out.println(it.next());
	}
		public static void main(String[] args) {
			List<String> li = new ArrayList<>();
			li.add("Ankit");
			li.add("Delhi");
			li.add("NAnms");
	        li.add("Sam");
	        li.add("Paris");
			
			printAll(li);
		}

		
	
}
