package List;

import java.util.*;

public class P05 {
	

	public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<String>();
        
        list.add("January");
        list.add("Februaru");
        list.add("March");
        list.add("April");
        list.add("May");
        list.add("June");
        list.add("July");
        list.add("August");
        list.add("September");
        list.add("October");
        list.add("November");
        list.add("Decmeber");

		
		
		System.out.println("Months are : " + list);
		


	}

}