package List;

import java.util.Iterator;
import java.util.Vector;

class Employees {
	private int id;
	private String name;
	private String address;
	private Double salary;
	
	public Employees(int id, String name, String address, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	
	
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", salary=" + salary + "]";
	}
}

public class P07 {

	public static void main(String[] args) {
		Vector<Employees> list = new Vector<>();
		
		list.add(new Employees(101, "Sam", "123 colony, India", 20850.0));
		list.add(new Employees(102, "Arjun", "234 colony, India", 30450.0));
		list.add(new Employees(103, "Josh", "345 colony, India", 45800.0));
		list.add(new Employees(104, "Sean", "456 colony, India", 44780.0));
		
		Iterator<Employees> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}
