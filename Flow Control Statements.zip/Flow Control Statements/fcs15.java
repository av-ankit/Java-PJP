
import java.util.Scanner;
public class fcs15 {

	public static void main(String args[])
	{
		int num,r,su=0;
		System.out.println("Enter a number:");
		Scanner s=new Scanner(System.in);
		num=s.nextInt();
		while(num!=0)
		{
			r=num%10;
			su=su+r;
			num=num/10;
		}
		System.out.println(su);
	}
}
