

import java.util.Scanner;


class fcs08 {

			public static void main(String args[])
			{
				System.out.println("Enter a Code:");
				Scanner sc = new Scanner(System.in);
				char a= sc.next().charAt(0);
				switch(a) 
				{
				case 'R': System.out.print("RED");
							break;
				case 'B': System.out.print("Blue");
							break;
				
				case 'O': System.out.print("Orange");
							break;
					
				case 'G':System.out.print("Green");
							break;
							
				case 'Y': System.out.print("Yellow");
							break;
							
				case 'W': System.out.print("White");
							break;
								
				default : System.out.print("Invalid Code");
				}
				
			}
		


	}


