

import java.util.Scanner;

public class fcs18 {

	public static void main(String[] args) {
		

		Scanner s= new Scanner(System.in);
		System.out.print("Enter a number:");
		int n=s.nextInt(); 
		int r,sd=0,sdm=n;
		while(n!=0)
		{
			r=n%10;
			sd=sd*10+r;
			n=n/10;
		}
		 if(sdm==sd)
		 {
			 System.out.println("Palindrone");			 
		 }
		 else
		 {
			 System.out.println("Not Palindrone");
		 }
		
		
	}
}
