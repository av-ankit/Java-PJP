
import java.util.Scanner;
public class fcs17 {

	public static void main()
	{
		
		Scanner s= new Scanner(System.in);
		System.out.print("Enter a number:");
		int n=s.nextInt(); 
		int r,sd=0;
		while(n!=0)
		{
			r=n%10;
			sd=sd*10+r;
			n=n/10;
		}
		System.out.print(sd);
	}
}



