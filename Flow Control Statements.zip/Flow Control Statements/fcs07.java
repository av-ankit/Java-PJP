
import java.util.Scanner;
public class fcs07 {

	public static void main(String[] args) {
		
		char ch;
		int temp;
		Scanner s=new Scanner(System.in);
		System.out.print("enter a character");
		ch=s.next().charAt(0);
		
		if((int) ch>=97 && (int) ch <=122)
		{
		temp=(int) ch;
		temp= temp -32;
		ch= (char)temp;
		}
		else
		{
			temp=(int) ch;
			temp= temp +32;
			ch= (char)temp;
		}
		
		System.out.print(ch);
		

	}

}
