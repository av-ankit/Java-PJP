
import java.util.Scanner;
public class fcs14 {
public static void main(String args[])
{
	int a,f=0;
	System.out.println("Enter a number:");
	Scanner s=new Scanner(System.in);
	
//int a=Integer.parseInt(args[0]),f=0;
	a=s.nextInt();
	
	if(a>=-2147483648 && a<=2147483647)
	{
		if(a==0)
{
	System.out.println("0 is neither prime nor composite");
}
else if(a==1)
{
	System.out.println("1 is neither prime nor composite");
}
else
{
	for(int i=2;i<=a/2;i++)
	{
		if(a%i==0)
		{
			f=1;
			break;
		}
	}
	if(f==1)
	{
		System.out.println(a+" is not a prime number");
	}
	else
	{
		System.out.println(a+" is a prime number");
	}
}
	}
else
{
	System.out.println("Please enter an integer number");
}
	
	

}
}
