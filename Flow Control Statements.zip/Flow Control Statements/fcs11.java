

public class fcs11 {

	public static void ain(String[] args) {
		for(int i=23;i<57;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}

	}

}
