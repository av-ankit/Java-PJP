
import java.util.Scanner;
public class fcs12 {

	public static void main(String[] args) {
		int f=0;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter a number:");
		int n=s.nextInt();
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				f=1;
				break;
			}
		}
		if(f==1)
		{
			System.out.println("Not Prime");
			
		}
		else
		{
			System.out.println("Prime Number");
			
		}

	}

}
