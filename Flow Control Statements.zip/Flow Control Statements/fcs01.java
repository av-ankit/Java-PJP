

import java.util.Scanner;

public class fcs01 {
	public static void main(String args[])
	{
		
		Scanner s=new Scanner(System.in);
		int n;
		System.out.println("Enter the number");
		n=s.nextInt();
		
		if(n==0)
			System.out.println("ZERO");
		else if(n>0)
			System.out.println("Positive");
		else
			System.out.println("Negative");
		
	}
}
