

import java.util.Scanner;

public class fcs02 {
	public static void main(String args[])
	{
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a no.");
		n= s.nextInt();
		 
		if(n%2==0)
			System.out.println("Even");
		else
			System.out.println("Odd");
	}
}
