
import java.util.Scanner;

public class fcs16 {

	public static void main(String[] args) {
Scanner s=new Scanner(System.in);
		int i,n;
		System.out.print("enter no of rows");
		n=s.nextInt();
		
		for(i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
