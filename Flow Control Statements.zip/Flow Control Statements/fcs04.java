
public class fcs04 {
public static void main(String args[])
{
	char a='s';
	char b='a';
	
	if(a>b)
	{
		System.out.println(b+","+a);
	}
	else
	{
		System.out.println(a+","+b);
	}
}
}
