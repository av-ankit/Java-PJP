package Set;
import java.util.*;
public class P02 {
public static void main(String[] args)
{
	Set<String> hs=new HashSet<String>();
	
	hs.add("Ankit");
	hs.add("Sam");
	hs.add("Ronny");
	hs.add("Mike");
	
	Iterator<String> i=hs.iterator();
	while(i.hasNext())
	{
		System.out.print(i.next()+" ");
	}
	
}
}
